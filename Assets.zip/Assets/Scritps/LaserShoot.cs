using System.Security.Cryptography;
using UnityEngine;

public class LaserShoot : MonoBehaviour
{

    public GameObject laserPrefab; //prefab del láser. 
    public Transform shootPoint; //el punto donde se disparará el láser
    public float laserSpeed = 20F; //velocidad del l�ser al salir disparado. 
    public float offset = 10F;
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
       if (Input.GetKeyDown(KeyCode.Space))
        {
            ShootLaser();
        }
    }

    void ShootLaser()
    {
        //creamos el laser (lo instanciamos)

        GameObject laser1 = Instantiate(laserPrefab, shootPoint.position, shootPoint.rotation);

        Vector3 laser2Position = shootPoint.position + new Vector3(offset, 0, 0);
        GameObject laser2 = Instantiate(laserPrefab,laser2Position, shootPoint.rotation);

        
    }

}
